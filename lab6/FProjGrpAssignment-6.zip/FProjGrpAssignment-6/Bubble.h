#pragma once

/* Bubble Sort Function Prototype*/

void BubbleSort(int* arr, int n);