#pragma once
/* Insertion Sort Function Prototype*/

void InsertionSort(int* arr, int n);