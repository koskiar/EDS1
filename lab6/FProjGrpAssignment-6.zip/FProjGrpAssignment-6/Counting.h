#pragma once
/* Counting Sort Function Prototype
*/

//GeeksForGeeks (2023) Counting Sort source code (Version 1.0) [Source code]. https://www.geeksforgeeks.org/counting-sort/
void CountingSort(int* arr, int n);
void CountingSort(int* arr, int n, int exp);