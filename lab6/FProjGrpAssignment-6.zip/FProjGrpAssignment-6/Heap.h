#pragma once
/* Heap Sort Function Prototype
*/

//GeeksForGeeks (2023) GeeksForGeeks source code (Version 1.0) [Source code]. https://www.geeksforgeeks.org/insertion-sort/
void HeapSort(int arr[], int N);
void heapify(int* arr, int N, int i);
void swaph(int* arr, int i, int j); // helper swap function