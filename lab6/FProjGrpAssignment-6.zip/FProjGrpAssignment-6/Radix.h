#pragma
#include "Counting.h"
/* Radix Sort Function Prototype */

//GeeksForGeeks (2023) Radix Sort source code (Version 1.0) [Source code]. https://www.geeksforgeeks.org/radix-sort/
void RadixSort(int* arr, int n);
int getMax(int* arr, int n);
