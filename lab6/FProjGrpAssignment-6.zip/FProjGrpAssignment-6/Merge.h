#pragma once
/* Merge Function Prototypes
*/

//GeeksForGeeks (2023) Merge Sort Algorithm source code (Version 1.0) [Source code]. https://www.geeksforgeeks.org/merge-sort/
void merge(int* array, int const left, int const mid, int const right);
void MergeSort(int* array, int const begin, int const end);